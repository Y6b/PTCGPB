# PTCGP Bot (Python Port) - Status & Handoff

## Current Status (August 2024)
The Python port is currently structurally complete but functionally stubbed. The core architecture is in place to orchestrate multiple Android emulators concurrently and run them through CustomTkinter. 

### What is DONE:
*   **Architecture Setup (`src/main.py`)**: Uses `multiprocessing` to run bot instances (`BotWorker`) concurrently without blocking the `CustomTkinter` GUI loop.
*   **Cross-Platform Emulators (`src/core/emulators.py`)**: Auto-detects and connects to MuMu Player (Windows/macOS) and Waydroid (Linux).
*   **ADB Wrapper (`src/core/adb.py`)**: Wraps `adbutils` to perform taps, swipes, text entry, and screenshots natively.
*   **Vision Engine (`src/core/vision.py`)**: OpenCV template matching is implemented to replace AHK's Gdip ImageSearch.
*   **GUI (`src/gui/app.py`)**: A modern CustomTkinter interface is built, mirroring the core settings of the AHK script.
*   **State Machine Skeletons (`src/bot/states/`)**: The logical flows for Farming (`farming.py`), Wonderpick (`wonderpick.py`), and Trade Evaluation (`trade.py`) are outlined.

### What is PENDING (Immediate Next Steps):
*   **Coordinate Extraction**: Fill out the `Coordinates_Template.csv`. We need the exact pixel coordinates for clicks/swipes based on the target emulator's resolution (e.g., clicking the "Open Pack" button).
*   **Template Migration**: Extract the core `.png` files used by the AHK script's `ImageSearch` and move them into `src/assets/images/` for the Python `VisionEngine` to use.
*   **Logic Injection**: Replace the `# TODO` comments inside `src/bot/states/farming.py` and `wonderpick.py` with the actual `adb.click()` and `vision.find_template()` calls using the extracted coordinates/templates.

## How to Resume Development
1. Extract this folder (`ptcgp-python-port`) into your new GitHub repository.
2. Ensure you have Python 3.10+ installed.
3. Run `pip install -r requirements.txt`.
4. Run `python -m src.main` to boot the GUI and ensure the environment is healthy.
5. Begin populating `src/bot/states/farming.py` with real template matching calls.