# RCON Manager Flutter App - Project Plan

This document outlines the multi-phase implementation plan for building the cross-platform (Android/iOS) RCON management Flutter application. 
The app allows server administrators to securely manage private servers (e.g., Minecraft, Palworld) via a modern, intuitive UI.

## Phase 1: Project Initialization & Architecture Setup (Completed)
1. **Initialize Flutter Project**: Create a new Flutter app targeting Android and iOS.
2. **Architecture & State Management**: Set up Riverpod for robust state management and establish a clean folder structure (Domain, Data, Presentation layers).
3. **Theming**: Implement a modern UI theme system using `flex_color_scheme` with support for switching between Light and Dark modes.

## Phase 2: UI Wireframing with Mock Data (Completed)
1. **Login Wireframe**: Build the login screen with mock buttons for Google, Facebook, and X social logins.
2. **Dashboard Wireframe**: Build the main server list interface displaying mock saved private servers with online/offline indicators.
3. **Server Control Wireframe (Minecraft & Palworld)**: Build the server detail screen featuring game-specific quick-action buttons (e.g., Kick, Ban, Time Set for Minecraft; Broadcast, Save for Palworld) and a custom raw RCON console interface, populated with mock log data.

## Phase 3: Backend & Authentication (Firebase) (Upcoming)
1. **Firebase Configuration**: Integrate Firebase Core for both Android and iOS platforms.
2. **Authentication Flow**: Implement actual Firebase Authentication logic to support Google, Facebook, and X sign-ins.

## Phase 4: Secure Data Storage (Upcoming)
1. **Local Security**: Implement `flutter_secure_storage` to safely cache and encrypt RCON passwords locally on the user's device.
2. **Database Security**: Setup Firestore to store server configurations (IP, Port, Game Type) and ensure RCON credentials stored in the backend are properly encrypted.

## Phase 5: RCON Protocol Implementation (Upcoming)
1. **Core RCON Client**: Implement the Dart-based logic for TCP connection, RCON authentication, and bi-directional packet communication.
2. **Command Integration**: Wire the Minecraft and Palworld quick-action buttons to send actual, configured RCON packets.
3. **Custom Console**: Wire the custom text field to send raw, user-defined commands and parse incoming server logs into the UI.

## Phase 6: Polish & Final Submission (Upcoming)
1. **Testing & QA**: Write and run integration and unit tests for critical paths.
2. **Final Review**: Validate functionality and finalize the application for release.
